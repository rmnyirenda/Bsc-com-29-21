#include "contact.h"
#include <iostream>
#include <fstream>
#include "phoneBook.h"

using namespace std;

int main(){
    PhoneBook phoneBook = PhoneBook();

    phoneBook.Run();

    return 0;
    }